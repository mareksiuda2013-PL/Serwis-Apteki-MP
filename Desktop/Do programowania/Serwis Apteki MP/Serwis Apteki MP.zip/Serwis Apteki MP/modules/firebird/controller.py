from services.firebird.installation_service import InstallationService


class FirebirdController:

    def __init__(self):

        self.installation_service = InstallationService()

    def installations(self):

        return self.installation_service.find_installations()