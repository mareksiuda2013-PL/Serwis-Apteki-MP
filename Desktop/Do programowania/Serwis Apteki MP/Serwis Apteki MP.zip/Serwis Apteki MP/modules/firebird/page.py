from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QListWidget,
    QPushButton,
)

from .controller import FirebirdController


class FirebirdPage(QWidget):

    def __init__(self):

        super().__init__()

        self.controller = FirebirdController()

        layout = QVBoxLayout(self)

        self.list = QListWidget()

        self.refresh_button = QPushButton("Odśwież")

        layout.addWidget(self.list)

        layout.addWidget(self.refresh_button)

        self.refresh_button.clicked.connect(
            self.refresh
        )

        self.refresh()

    def refresh(self):

        self.list.clear()

        for fb in self.controller.installations():

            self.list.addItem(
                f"{fb.version}    {fb.install_path}"
            )